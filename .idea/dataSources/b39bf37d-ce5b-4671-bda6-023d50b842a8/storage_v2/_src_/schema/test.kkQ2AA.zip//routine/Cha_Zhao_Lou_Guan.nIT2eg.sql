create
    definer = root@localhost procedure 查找楼管(INOUT 学生ID int)
SELECT `楼管表`.`姓名` 楼管名字,`楼管表`.`手机号码`
	FROM `楼管表`,`学生表`,`宿舍表`
	WHERE `学生表`.`学生ID`= `学生ID` AND
				`宿舍表`.`宿舍ID`=`学生表`.`宿舍ID` AND
				`楼管表`.`管理员ID`=`宿舍表`.`管理员ID`;

