create definer = root@localhost view 宿舍_32502 as
select `test`.`学生表`.`学生ID` AS `学生ID`, `test`.`学生表`.`手机号码` AS `手机号码`
from `test`.`学生表`
where (`test`.`学生表`.`宿舍ID` = '32502');

