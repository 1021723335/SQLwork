create definer = root@localhost trigger 增加更新宿舍表_1
    after insert
    on 学生表
    for each row
    update 宿舍表
    set 宿舍表.人数 = 宿舍表.人数+1
    where 宿舍表.宿舍ID = new.宿舍ID;

